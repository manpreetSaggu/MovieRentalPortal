package com.moviePortal.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.moviePortal.dto.Movie;
import com.moviePortal.dto.Rent;
import com.moviePortal.util.ResourceHelper;

public class RentDao {

	public boolean insertRent(Rent rent) throws Exception {
		boolean isInsertSuccess = false;
		PreparedStatement ps = ResourceHelper.getConnection().prepareStatement(
				"insert into rent values(?,?,?,?,?,?)");
		ps.setString(1, rent.getUserName());
		ps.setString(2, rent.getMovieName());
		ps.setString(3, rent.getMovieType());
		ps.setString(4, rent.getStartDateOfRent());
		ps.setLong(5, rent.getCost());
		ps.setString(6, rent.getEndDateofRent());
		ps.setString(7,rent.getNoOfDays());
		int iRowInserted = ps.executeUpdate();
		if (iRowInserted == 1)
			isInsertSuccess = true;
		return isInsertSuccess;
}
	
	public Rent findRentedMovies(String userName) throws Exception {
		Rent rent = null;
		PreparedStatement ps = ResourceHelper.getConnection().prepareStatement(
				"select * from rent where userName= ? and isRentExpired='N'");
		ps.setString(1, userName);                
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			rent = new Rent();
			rent.setUserName(rs.getString(1));
			rent.setMovieName(rs.getString(2));
			rent.setMovieType(rs.getString(3));
			rent.setIsRentExpired(rs.getString(6));
		}
		return rent;
	}
}
