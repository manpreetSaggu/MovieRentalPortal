package com.moviePortal.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.moviePortal.dto.User;
import com.moviePortal.util.ResourceHelper;

public class UserDao {

	public boolean insertUsers(User user) throws Exception {
		boolean flag = false;
		PreparedStatement ps = ResourceHelper.getConnection().prepareStatement(
				"insert into users values(?,?,?,?)");
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getPassword());
		ps.setInt(3, user.getAccountNo());
		ps.setString(4, user.getEmail());
		int i = ps.executeUpdate();
		if (i == 1)
			flag = true;
		return flag;
	}

	public User findUsers(String username, String password) throws Exception {
		User user = null;
		PreparedStatement ps = ResourceHelper.getConnection().prepareStatement(
				"select * from users where username=? and password=?");
		ps.setString(1, username);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			user = new User();
			user.setUserName(rs.getString(1));
			user.setPassword(rs.getString(2));
			user.setAccountNo(rs.getInt(3));
			user.setEmail(rs.getString(4));
		}
		return user;
	}
}
