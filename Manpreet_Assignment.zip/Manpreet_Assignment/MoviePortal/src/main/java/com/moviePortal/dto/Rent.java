package com.moviePortal.dto;



public class Rent {

	private String userName;
	private String movieName;
	private String movieType;
	private String startDateOfRent;
	private long cost;
	private String EndDateofRent;
	private String noOfDays;
	private String isRentExpired;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieType() {
		return movieType;
	}
	public void setMovieType(String movieType) {
		this.movieType = movieType;
	}

	public long getCost() {
		return cost;
	}
	public void setCost(long cost) {
		this.cost = cost;
	}
	public String getStartDateOfRent() {
		return startDateOfRent;
	}
	public void setStartDateOfRent(String startDateOfRent) {
		this.startDateOfRent = startDateOfRent;
	}
	public String getEndDateofRent() {
		return EndDateofRent;
	}
	public void setEndDateofRent(String endDateofRent) {
		EndDateofRent = endDateofRent;
	}
	public String getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}
	public String getIsRentExpired() {
		return isRentExpired;
	}
	public void setIsRentExpired(String isRentExpired) {
		this.isRentExpired = isRentExpired;
	}

	
}
