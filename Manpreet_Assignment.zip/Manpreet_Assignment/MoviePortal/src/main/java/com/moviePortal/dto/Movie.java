package com.moviePortal.dto;

import java.math.BigDecimal;

public class Movie {

	private String title;
	private int year;
	private String category;
	private long rentalPrice;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public long getRentalPrice() {
		return rentalPrice;
	}
	public void setRentalPrice(long rentalPrice) {
		this.rentalPrice = rentalPrice;
	}
	
	
}
