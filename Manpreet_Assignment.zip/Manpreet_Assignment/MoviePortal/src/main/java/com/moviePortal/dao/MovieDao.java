package com.moviePortal.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.moviePortal.dto.Movie;
import com.moviePortal.util.ResourceHelper;


public class MovieDao {
	/**
	 * This method is used to insert records in movie table
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	public boolean insertMovie(Movie movie) throws Exception {
		boolean isInsertSuccess = false;
		PreparedStatement ps = ResourceHelper.getConnection().prepareStatement(
				"insert into movie values(?,?,?,?)");
		ps.setString(1, movie.getTitle());
		ps.setInt(2, movie.getYear());
		ps.setString(3, movie.getCategory());
		ps.setLong(4, movie.getRentalPrice());

		int iRowInserted = ps.executeUpdate();
		if (iRowInserted == 1)
			isInsertSuccess = true;
		return isInsertSuccess;
}
	
	/**
	 * This method is used to find records in movie table
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	public Movie findMovies(String title, int year) throws Exception {
	Movie movie = null;
	PreparedStatement ps = ResourceHelper.getConnection().prepareStatement(
			"select * from movies where title=? and year=?");
	ps.setString(1, title);
	ps.setInt(2, year);
	ResultSet rs = ps.executeQuery();
	if (rs.next()) {
		movie = new Movie();
		movie.setTitle(rs.getString(1));
		movie.setYear(rs.getInt(2));
		movie.setCategory(rs.getString(3));
		movie.setRentalPrice(rs.getLong(4));
	}
	return movie;
}
	
	
}
