package com.moviePortal.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class ResourceHelper {
	private static Connection connection;

	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "moviePortal",
					"moviePortal");
		} catch (Exception e) {
			System.out.println("Error while connecting to Database");
		}
		return connection;
	}
}
