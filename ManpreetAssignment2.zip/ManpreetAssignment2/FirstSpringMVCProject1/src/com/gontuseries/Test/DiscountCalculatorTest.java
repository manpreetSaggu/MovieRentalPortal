package com.gontuseries.Test;

import com.gontuseries.CustomerModel.Customer;
import com.gontuseries.Service.DiscountCalculatorImpl;
import junit.framework.TestCase;

public class DiscountCalculatorTest extends TestCase {

    public void testHandleRequestView() throws Exception{		
    	DiscountCalculatorImpl service = new DiscountCalculatorImpl();
    	
        //Uncomment to Test : When User Role is "Store Employee" or "Store Affiliate" or "Old Customer" but has Product type as "Grosery"
 /*   	Customer customer= new Customer();
    	customer.setUserName("Manpreet");
    	customer.setCustomerRole("Store Employee");
    	customer.setProductType("Grosery");
    	customer.setBillAmount(1000.00);*/
    	
    	//Uncomment to Test : When User Role is Store Employee and Product type is other than "Grosery"
/*    	Customer customer= new Customer();
    	customer.setUserName("Manpreet");
    	customer.setCustomerRole("Store Employee");
    	customer.setProductType("Medicines");
    	customer.setBillAmount(1000.00);*/
    	
    	//Uncomment to Test : When User Role is Store Affiliate and Product type is other than "Grosery"
    	/*    	Customer customer= new Customer();
    	    	customer.setUserName("Manpreet");
    	    	customer.setCustomerRole("Store Affiliate");
    	    	customer.setProductType("Medicines");
    	    	customer.setBillAmount(1000.00);*/
    	
    	//Uncomment to Test : When User Role is Old Customer and Product type is other than "Grosery"
    	    	Customer customer= new Customer();
    	    	customer.setUserName("Manpreet");
    	    	customer.setCustomerRole("Old Customer");
    	    	customer.setProductType("Medicines");
    	    	customer.setBillAmount(1000.00);
    	//Call to service class
        service.calculateDiscount(customer);
        
         //Uncomment to Test : When User Role is "Store Employee" or "Store Affiliate" or "Old Customer" but has Product type as "Grosery"
        /*assertEquals("950",customer.getBillAmount().toString());*/
        
        //Uncomment to Test: When User Role is Store Employee and Product type is other than "Grosery"
        /*assertEquals("665.0",customer.getBillAmount().toString());*/
        
        //Uncomment to Test: When User Role is Store Affiliate and Product type is other than "Grosery"
        /*assertEquals("855.0",customer.getBillAmount().toString());*/
        
      //Uncomment to Test: When User Role is Old Customer and Product type is other than "Grosery"
        assertEquals("905.0",customer.getBillAmount().toString());
        
    }
}