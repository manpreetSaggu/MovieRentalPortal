package com.gontuseries.hellocontroller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.gontuseries.CustomerModel.Customer;
import com.gontuseries.Service.DiscountCalculator;

public class TextBoxController extends SimpleFormController{

	private DiscountCalculator discountCalculator;
	
	public DiscountCalculator getDiscountCalculator() {
		return discountCalculator;
	}

	public void setDiscountCalculator(DiscountCalculator discountCalculator) {
		this.discountCalculator = discountCalculator;
	}

	public TextBoxController(){
		setCommandClass(Customer.class);
		setCommandName("customerForm");
	}

	@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
		HttpServletResponse response, Object command, BindException errors)
		throws Exception {

		Customer customer = (Customer)command;
		discountCalculator.calculateDiscount(customer);
		return new ModelAndView("CustomerSuccess","customer",customer);

	}
}
