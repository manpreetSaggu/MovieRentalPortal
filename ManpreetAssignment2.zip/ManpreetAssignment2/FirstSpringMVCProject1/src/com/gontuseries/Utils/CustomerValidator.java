package com.gontuseries.Utils;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.gontuseries.CustomerModel.Customer;

public class CustomerValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
		//just validate the Customer instances
		return Customer.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName",
			"required.userName", "User Name name is required.");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "customerRole",
				"required.customerRole", "Customer Role name is required.");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "billAmount",
				"required.billAmount", "Bill Amount name is required.");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "productType",
				"required.productType", "Product Type name is required.");

	}

}