package com.gontuseries.Service;

import java.math.BigDecimal;

import com.gontuseries.CustomerModel.Customer;

public class DiscountCalculatorImpl implements DiscountCalculator{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void calculateDiscount(Customer customer) {
		// TODO Auto-generated method stub
		Double tempBillAmount=0.0;
		Double billAmount=customer.getBillAmount();
		if(!(("Grosery").equalsIgnoreCase(customer.getProductType()))){
			if(("Store Employee").equalsIgnoreCase(customer.getCustomerRole())){
				tempBillAmount = billAmount-((0.3) * (billAmount));
				customer.setBillAmount(tempBillAmount);
			}else if(("Store Affiliate").equalsIgnoreCase(customer.getCustomerRole())){
				tempBillAmount = billAmount-((0.1) * (billAmount));
				customer.setBillAmount(tempBillAmount);
			}else if(("Old Customer").equalsIgnoreCase(customer.getCustomerRole())){
				tempBillAmount = billAmount-((0.05) * (billAmount));
				customer.setBillAmount(tempBillAmount);
			}

		}
		if(customer.getBillAmount() > 100){
			Double afterPerDiscountAmount = customer.getBillAmount();
			int icount = (int) (afterPerDiscountAmount/100);
			tempBillAmount = afterPerDiscountAmount - (icount*5);
			customer.setBillAmount(tempBillAmount);
		}
	}



}
