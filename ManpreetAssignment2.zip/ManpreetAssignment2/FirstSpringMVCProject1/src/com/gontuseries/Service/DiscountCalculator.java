package com.gontuseries.Service;

import java.io.Serializable;

import com.gontuseries.CustomerModel.Customer;

public interface DiscountCalculator extends Serializable{

	public void calculateDiscount(Customer customer);
}
